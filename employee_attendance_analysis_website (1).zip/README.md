# Employee Attendance Analysis System

A beginner-friendly Flask + SQLite web application.

## Features
- Dashboard with employee count and today's attendance summary
- Add and remove employees
- Mark an employee Present, Absent, or Late
- Update an employee's attendance for a date
- Attendance report with optional date range
- SQLite database is created automatically

## Run in VS Code (Windows)

1. Extract this ZIP file.
2. Open the `employee_attendance_analysis` folder in VS Code.
3. Open the VS Code terminal in that folder.
4. Create a virtual environment (recommended):

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

5. Install Flask:

   ```powershell
   py -m pip install -r requirements.txt
   ```

6. Start the website:

   ```powershell
   py app.py
   ```

7. Open Chrome and visit: http://127.0.0.1:8080

If PowerShell blocks package installation due to your computer's application-control policy, use an approved Python environment or ask your institution's administrator for help.

## Database
The app creates `attendance.db` in the project folder automatically when first run. It uses SQLite, so no separate database server is required.

## Notes
This is a classroom/demo project. Before using it for real employee records, add authentication, role-based access, backups, audit logging, and appropriate data protection.
