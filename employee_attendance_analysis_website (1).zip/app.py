from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import date

app = Flask(__name__)
app.secret_key = "attendance-demo-key"
DB = "attendance.db"

def connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                department TEXT NOT NULL,
                email TEXT
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id INTEGER NOT NULL,
                day TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late')),
                UNIQUE(employee_id, day),
                FOREIGN KEY(employee_id) REFERENCES employees(id)
            )
        """)

@app.route("/")
def dashboard():
    with connect() as con:
        employees = con.execute("SELECT * FROM employees ORDER BY name").fetchall()
        today = date.today().isoformat()
        total = len(employees)
        present = con.execute("SELECT COUNT(*) FROM attendance WHERE day=? AND status='Present'", (today,)).fetchone()[0]
        absent = con.execute("SELECT COUNT(*) FROM attendance WHERE day=? AND status='Absent'", (today,)).fetchone()[0]
        late = con.execute("SELECT COUNT(*) FROM attendance WHERE day=? AND status='Late'", (today,)).fetchone()[0]
        recent = con.execute("""
            SELECT a.day, a.status, e.name, e.department
            FROM attendance a JOIN employees e ON e.id=a.employee_id
            ORDER BY a.day DESC, a.id DESC LIMIT 8
        """).fetchall()
    rate = round((present / total) * 100) if total else 0
    return render_template("index.html", employees=employees, total=total,
                           present=present, absent=absent, late=late,
                           rate=rate, recent=recent, today=today)

@app.route("/employees", methods=["POST"])
def add_employee():
    name = request.form.get("name", "").strip()
    department = request.form.get("department", "").strip()
    email = request.form.get("email", "").strip()
    if not name or not department:
        flash("Employee name and department are required.")
    else:
        try:
            with connect() as con:
                con.execute("INSERT INTO employees(name, department, email) VALUES(?,?,?)",
                            (name, department, email))
            flash("Employee added successfully.")
        except sqlite3.Error:
            flash("Could not add employee. Please check the details.")
    return redirect(url_for("dashboard"))

@app.route("/attendance", methods=["POST"])
def mark_attendance():
    employee_id = request.form.get("employee_id")
    day = request.form.get("day") or date.today().isoformat()
    status = request.form.get("status")
    if status not in ("Present", "Absent", "Late"):
        flash("Choose a valid attendance status.")
    else:
        try:
            with connect() as con:
                con.execute("""
                    INSERT INTO attendance(employee_id, day, status) VALUES(?,?,?)
                    ON CONFLICT(employee_id, day) DO UPDATE SET status=excluded.status
                """, (employee_id, day, status))
            flash("Attendance saved.")
        except sqlite3.Error:
            flash("Could not save attendance. Select an employee first.")
    return redirect(url_for("dashboard"))

@app.route("/report")
def report():
    start = request.args.get("start", "")
    end = request.args.get("end", "")
    query = """
        SELECT e.id, e.name, e.department,
               SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present,
               SUM(CASE WHEN a.status='Absent' THEN 1 ELSE 0 END) AS absent,
               SUM(CASE WHEN a.status='Late' THEN 1 ELSE 0 END) AS late,
               COUNT(a.id) AS marked
        FROM employees e LEFT JOIN attendance a ON a.employee_id=e.id
    """
    params = []
    if start and end:
        query += " AND a.day BETWEEN ? AND ?"
        params.extend([start, end])
    query += " GROUP BY e.id ORDER BY e.name"
    with connect() as con:
        rows = con.execute(query, params).fetchall()
    return render_template("report.html", rows=rows, start=start, end=end)

@app.route("/employee/<int:employee_id>/delete", methods=["POST"])
def delete_employee(employee_id):
    with connect() as con:
        con.execute("DELETE FROM attendance WHERE employee_id=?", (employee_id,))
        con.execute("DELETE FROM employees WHERE id=?", (employee_id,))
    flash("Employee and attendance records deleted.")
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=8080)
